-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : 99chemh
-- 
-- Part : #1
-- Date : 2015-07-14 15:44:53
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `cw_action`
-- -----------------------------
DROP TABLE IF EXISTS `cw_action`;
CREATE TABLE `cw_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `cw_action`
-- -----------------------------
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `cw_action_log`;
CREATE TABLE `cw_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1818 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `cw_action_log`
-- -----------------------------
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_action_log` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_addons`
-- -----------------------------
DROP TABLE IF EXISTS `cw_addons`;
CREATE TABLE `cw_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `cw_addons`
-- -----------------------------
INSERT INTO `cw_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_addons` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_addons` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_ads`
-- -----------------------------
DROP TABLE IF EXISTS `cw_ads`;
CREATE TABLE `cw_ads` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL,
  `title` char(200) NOT NULL,
  `url` char(200) NOT NULL,
  `picture` char(200) DEFAULT NULL,
  `target` int(1) NOT NULL,
  `create_time` int(10) DEFAULT NULL,
  `update_time` int(10) DEFAULT NULL,
  `status` int(4) NOT NULL,
  `SortId` int(11) DEFAULT NULL COMMENT '产品分类ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_ads`
-- -----------------------------
INSERT INTO `cw_ads` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ads` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ads` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ads` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ads` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ads` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ads` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_ads_sort`
-- -----------------------------
DROP TABLE IF EXISTS `cw_ads_sort`;
CREATE TABLE `cw_ads_sort` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `type` varchar(100) NOT NULL,
  `width` varchar(100) DEFAULT NULL,
  `height` varchar(100) DEFAULT NULL,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `menuid` int(10) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `Belong` int(11) DEFAULT '0' COMMENT '0表示关闭，1表示开启，开启所属广告',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_ads_sort`
-- -----------------------------
INSERT INTO `cw_ads_sort` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ads_sort` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ads_sort` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_apply`
-- -----------------------------
DROP TABLE IF EXISTS `cw_apply`;
CREATE TABLE `cw_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '团购编号',
  `brand` varchar(255) NOT NULL COMMENT '团购品牌',
  `cars` varchar(255) NOT NULL COMMENT '团购车系',
  `deploy` varchar(255) NOT NULL COMMENT '团购配置',
  `username` varchar(255) NOT NULL COMMENT '团购人姓名',
  `area` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL COMMENT '团购地址',
  `mobile` varchar(255) NOT NULL COMMENT '团购人手机',
  `sex` tinyint(2) NOT NULL DEFAULT '0' COMMENT '团购人性别',
  `mortgage` tinyint(2) NOT NULL,
  `tip` text COMMENT '注备',
  `update_time` int(10) NOT NULL COMMENT '更新时间',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `status` smallint(6) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `cw_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `cw_attachment`;
CREATE TABLE `cw_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `cw_attention`
-- -----------------------------
DROP TABLE IF EXISTS `cw_attention`;
CREATE TABLE `cw_attention` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自动编号',
  `uid` int(11) NOT NULL COMMENT '用户编号',
  `price` float NOT NULL COMMENT '商品价格',
  `pro_id` int(11) NOT NULL COMMENT '商品编号',
  `creat_time` int(10) NOT NULL COMMENT '加入时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='我的关注';

-- -----------------------------
-- Records of `cw_attention`
-- -----------------------------
INSERT INTO `cw_attention` VALUES ('', '', '', '', '');
INSERT INTO `cw_attention` VALUES ('', '', '', '', '');
INSERT INTO `cw_attention` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `cw_attribute`;
CREATE TABLE `cw_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `cw_attribute`
-- -----------------------------
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_attribute` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `cw_auth_extend`;
CREATE TABLE `cw_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `cw_auth_extend`
-- -----------------------------
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');
INSERT INTO `cw_auth_extend` VALUES ('', '', '');

-- -----------------------------
-- Table structure for `cw_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `cw_auth_group`;
CREATE TABLE `cw_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_auth_group`
-- -----------------------------
INSERT INTO `cw_auth_group` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_group` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_group` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `cw_auth_group_access`;
CREATE TABLE `cw_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_auth_group_access`
-- -----------------------------
INSERT INTO `cw_auth_group_access` VALUES ('', '');
INSERT INTO `cw_auth_group_access` VALUES ('', '');
INSERT INTO `cw_auth_group_access` VALUES ('', '');
INSERT INTO `cw_auth_group_access` VALUES ('', '');
INSERT INTO `cw_auth_group_access` VALUES ('', '');
INSERT INTO `cw_auth_group_access` VALUES ('', '');

-- -----------------------------
-- Table structure for `cw_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `cw_auth_rule`;
CREATE TABLE `cw_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=456 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_auth_rule`
-- -----------------------------
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_auth_rule` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_category`
-- -----------------------------
DROP TABLE IF EXISTS `cw_category`;
CREATE TABLE `cw_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `lefttype` int(1) NOT NULL,
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `group` varchar(50) DEFAULT NULL,
  `model_append` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `isgood` int(11) DEFAULT '0' COMMENT '是否推荐',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `cw_category`
-- -----------------------------
INSERT INTO `cw_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_category` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_category_model`
-- -----------------------------
DROP TABLE IF EXISTS `cw_category_model`;
CREATE TABLE `cw_category_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `pid` int(10) NOT NULL COMMENT '栏目ID',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=115 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `cw_category_model`
-- -----------------------------
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_category_model` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_channel`
-- -----------------------------
DROP TABLE IF EXISTS `cw_channel`;
CREATE TABLE `cw_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_channel`
-- -----------------------------
INSERT INTO `cw_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_channel` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_channel` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_company`
-- -----------------------------
DROP TABLE IF EXISTS `cw_company`;
CREATE TABLE `cw_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `com_name` varchar(255) NOT NULL COMMENT '公司名称',
  `com_type` varchar(255) NOT NULL COMMENT '公司类型',
  `com_tel` varchar(255) NOT NULL COMMENT '公司电话',
  `com_address` varchar(255) NOT NULL COMMENT '公司地址',
  `com_logo` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_company`
-- -----------------------------
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_company` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_complain`
-- -----------------------------
DROP TABLE IF EXISTS `cw_complain`;
CREATE TABLE `cw_complain` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '投诉编号',
  `uid` int(11) NOT NULL COMMENT '用户编号',
  `order_id` int(11) NOT NULL COMMENT '订单编号',
  `typeValue` smallint(6) NOT NULL COMMENT '投诉类型',
  `content` text NOT NULL COMMENT '投诉内容',
  `create_time` int(10) NOT NULL COMMENT '投诉时间',
  `status` smallint(6) NOT NULL DEFAULT '1' COMMENT '投诉状态（1为未完成0为完成）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_complain`
-- -----------------------------
INSERT INTO `cw_complain` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_complain` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_complain` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_complain` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_config`
-- -----------------------------
DROP TABLE IF EXISTS `cw_config`;
CREATE TABLE `cw_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `is_dev` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开发模式下才显示，0：否，1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_config`
-- -----------------------------
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_document`
-- -----------------------------
DROP TABLE IF EXISTS `cw_document`;
CREATE TABLE `cw_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `brand_id` int(10) DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `deal_length` int(11) NOT NULL DEFAULT '0' COMMENT '交易数量',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '价格',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=897 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `cw_document`
-- -----------------------------
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_document` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `cw_document_article`;
CREATE TABLE `cw_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `cw_document_article`
-- -----------------------------
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');
INSERT INTO `cw_document_article` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `cw_document_download`;
CREATE TABLE `cw_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `com_name` varchar(255) NOT NULL COMMENT '公司名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `cw_document_product`
-- -----------------------------
DROP TABLE IF EXISTS `cw_document_product`;
CREATE TABLE `cw_document_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `price` int(10) unsigned NOT NULL COMMENT '价格',
  `content` text NOT NULL COMMENT '内容',
  `area` varchar(100) NOT NULL COMMENT '地区',
  `tyle` varchar(100) NOT NULL COMMENT '类别',
  `pricess` varchar(100) NOT NULL COMMENT '价位',
  `taste` varchar(100) NOT NULL COMMENT '口味',
  `package` varchar(100) NOT NULL COMMENT '包装',
  `country` varchar(100) NOT NULL COMMENT '国别',
  `weight` text NOT NULL COMMENT '重量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `cw_file`
-- -----------------------------
DROP TABLE IF EXISTS `cw_file`;
CREATE TABLE `cw_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `cw_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `cw_hooks`;
CREATE TABLE `cw_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_hooks`
-- -----------------------------
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_hooks` VALUES ('', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_like`
-- -----------------------------
DROP TABLE IF EXISTS `cw_like`;
CREATE TABLE `cw_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `creata_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_like`
-- -----------------------------
INSERT INTO `cw_like` VALUES ('', '', '', '');
INSERT INTO `cw_like` VALUES ('', '', '', '');
INSERT INTO `cw_like` VALUES ('', '', '', '');
INSERT INTO `cw_like` VALUES ('', '', '', '');
INSERT INTO `cw_like` VALUES ('', '', '', '');
INSERT INTO `cw_like` VALUES ('', '', '', '');
INSERT INTO `cw_like` VALUES ('', '', '', '');

-- -----------------------------
-- Table structure for `cw_linkage`
-- -----------------------------
DROP TABLE IF EXISTS `cw_linkage`;
CREATE TABLE `cw_linkage` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL COMMENT '上级ID',
  `name` char(30) NOT NULL COMMENT '标识',
  `title` char(100) NOT NULL COMMENT '标题',
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `sort` varchar(255) DEFAULT NULL COMMENT '所属类别',
  `picture` varchar(255) DEFAULT NULL COMMENT '商品图片',
  `fee` float NOT NULL COMMENT '邮费比例',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4397 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_linkage`
-- -----------------------------
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_linkage` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_member`
-- -----------------------------
DROP TABLE IF EXISTS `cw_member`;
CREATE TABLE `cw_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `picture` int(11) DEFAULT NULL COMMENT '用户头像',
  `nickname` text NOT NULL COMMENT '昵称',
  `sex` char(10) NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `address` varchar(255) DEFAULT NULL,
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '会员状态',
  `age` int(10) unsigned NOT NULL COMMENT '年龄',
  `user_type` smallint(6) NOT NULL DEFAULT '0' COMMENT '用户类型（0表示个体1表示经销商2表示供应商）',
  `face` int(10) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `cw_member`
-- -----------------------------
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_menu`
-- -----------------------------
DROP TABLE IF EXISTS `cw_menu`;
CREATE TABLE `cw_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=252 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_menu`
-- -----------------------------
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `cw_menu` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_model`
-- -----------------------------
DROP TABLE IF EXISTS `cw_model`;
CREATE TABLE `cw_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `cw_model`
-- -----------------------------
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_model` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_order`
-- -----------------------------
DROP TABLE IF EXISTS `cw_order`;
CREATE TABLE `cw_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `uid` int(11) NOT NULL COMMENT '会员id',
  `Length` int(11) NOT NULL COMMENT '产品数量',
  `payment` varchar(255) NOT NULL DEFAULT '支付宝' COMMENT '付支方式',
  `create_time` double(13,3) NOT NULL,
  `price` int(11) NOT NULL COMMENT '夺宝币',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态(-1表示删除1表示待付款2表示已付款)',
  `clinch` float NOT NULL COMMENT '成交价格',
  `wcorderid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_order`
-- -----------------------------
INSERT INTO `cw_order` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_order` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_order` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_order` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_orderlist`
-- -----------------------------
DROP TABLE IF EXISTS `cw_orderlist`;
CREATE TABLE `cw_orderlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户编号',
  `order_id` int(11) NOT NULL COMMENT '订单id',
  `pro_id` int(11) NOT NULL COMMENT '产品id',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `picture` varchar(255) NOT NULL COMMENT '图片',
  `price` int(11) NOT NULL COMMENT '单价',
  `mynum` int(8) NOT NULL DEFAULT '0' COMMENT '奖券号码',
  `length` int(11) NOT NULL DEFAULT '1' COMMENT ' 数量',
  `deletes` int(4) NOT NULL DEFAULT '0' COMMENT '隐藏订单',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3856 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_orderlist`
-- -----------------------------
INSERT INTO `cw_orderlist` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_orderlist` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_orderlist` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_orderlist` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_package`
-- -----------------------------
DROP TABLE IF EXISTS `cw_package`;
CREATE TABLE `cw_package` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `PackageName` varchar(200) NOT NULL COMMENT '套餐名称',
  `price` int(11) NOT NULL COMMENT '优惠价格',
  `create_time` int(11) NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_package`
-- -----------------------------
INSERT INTO `cw_package` VALUES ('', '', '', '');
INSERT INTO `cw_package` VALUES ('', '', '', '');
INSERT INTO `cw_package` VALUES ('', '', '', '');
INSERT INTO `cw_package` VALUES ('', '', '', '');
INSERT INTO `cw_package` VALUES ('', '', '', '');
INSERT INTO `cw_package` VALUES ('', '', '', '');
INSERT INTO `cw_package` VALUES ('', '', '', '');

-- -----------------------------
-- Table structure for `cw_packagelist`
-- -----------------------------
DROP TABLE IF EXISTS `cw_packagelist`;
CREATE TABLE `cw_packagelist` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `title` varchar(250) NOT NULL COMMENT '标题',
  `picture` int(11) NOT NULL COMMENT '图片',
  `price` int(11) NOT NULL COMMENT '价格',
  `packid` int(11) NOT NULL COMMENT '套餐ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_packagelist`
-- -----------------------------
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');
INSERT INTO `cw_packagelist` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_parameters`
-- -----------------------------
DROP TABLE IF EXISTS `cw_parameters`;
CREATE TABLE `cw_parameters` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL COMMENT '上级ID',
  `name` char(30) NOT NULL COMMENT '标识',
  `title` char(100) NOT NULL COMMENT '标题',
  `titlea` char(100) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `sort` varchar(255) DEFAULT NULL COMMENT '所属类别',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `cw_picture`
-- -----------------------------
DROP TABLE IF EXISTS `cw_picture`;
CREATE TABLE `cw_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1477 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_picture`
-- -----------------------------
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_picture` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_prints`
-- -----------------------------
DROP TABLE IF EXISTS `cw_prints`;
CREATE TABLE `cw_prints` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '晒单编号',
  `pro_id` int(11) NOT NULL COMMENT '奖品编号',
  `uid` int(11) NOT NULL COMMENT '用户编号',
  `say` text NOT NULL COMMENT '晒单文字',
  `pic` varchar(255) NOT NULL COMMENT '晒单图片',
  `create_time` int(10) NOT NULL COMMENT '发布时间',
  `status` smallint(4) NOT NULL DEFAULT '0' COMMENT '晒单状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `cw_procate`
-- -----------------------------
DROP TABLE IF EXISTS `cw_procate`;
CREATE TABLE `cw_procate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `recommend` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` text NOT NULL COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `lefttype` int(1) NOT NULL,
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `group` varchar(50) DEFAULT NULL,
  `model_append` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=286 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `cw_procate`
-- -----------------------------
INSERT INTO `cw_procate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_procate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_procate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_procate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_procate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_procate_model`
-- -----------------------------
DROP TABLE IF EXISTS `cw_procate_model`;
CREATE TABLE `cw_procate_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `pid` int(10) NOT NULL COMMENT '栏目ID',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=252 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `cw_procate_model`
-- -----------------------------
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_procate_model` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_product`
-- -----------------------------
DROP TABLE IF EXISTS `cw_product`;
CREATE TABLE `cw_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `brand_id` int(10) NOT NULL DEFAULT '0' COMMENT '品牌编号',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` varchar(40) NOT NULL COMMENT '标识',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL COMMENT '描述',
  `root` int(10) unsigned NOT NULL COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` double(13,3) NOT NULL DEFAULT '0.000' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `price` double unsigned NOT NULL COMMENT '价格',
  `total` int(10) unsigned NOT NULL COMMENT '总需人次',
  `join` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '已参与人次',
  `periods` varchar(255) NOT NULL COMMENT '奖品期数',
  `state` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '夺宝状态',
  `awardnum` int(10) unsigned NOT NULL COMMENT '中奖号码',
  `awarduser` int(10) NOT NULL COMMENT '中奖用户编号',
  `lottery` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '3D福彩中奖号码',
  `time_total` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '50个时间总和',
  `allnum` longtext NOT NULL COMMENT '所有幸运号码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=490 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `cw_product`
-- -----------------------------
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_product` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_product_prolist`
-- -----------------------------
DROP TABLE IF EXISTS `cw_product_prolist`;
CREATE TABLE `cw_product_prolist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `content` text NOT NULL COMMENT '内容',
  `picture` char(30) NOT NULL COMMENT '大图',
  `snjjfengge` varchar(100) NOT NULL COMMENT '风格',
  `brand` varchar(100) NOT NULL COMMENT '品牌',
  `caizhi` varchar(100) NOT NULL COMMENT '材质',
  `yangshi` varchar(100) NOT NULL COMMENT '样式',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=490 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `cw_product_prolist`
-- -----------------------------
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_product_prolist` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_purcate`
-- -----------------------------
DROP TABLE IF EXISTS `cw_purcate`;
CREATE TABLE `cw_purcate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `recommend` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `title` char(100) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `theme` varchar(50) NOT NULL DEFAULT '' COMMENT '团购主题',
  `explain` varchar(255) NOT NULL DEFAULT '' COMMENT '团购说明',
  `light` text NOT NULL COMMENT '团购亮点',
  `time` varchar(100) NOT NULL COMMENT '团购时间',
  `address` varchar(255) NOT NULL COMMENT '团购地址',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `lefttype` int(1) NOT NULL,
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `ads` int(10) NOT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `group` varchar(50) DEFAULT NULL,
  `model_append` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `review` char(30) NOT NULL COMMENT '团购回顾',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=299 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `cw_purcate`
-- -----------------------------
INSERT INTO `cw_purcate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purcate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purcate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purcate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purcate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purcate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purcate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purcate` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_purcate_model`
-- -----------------------------
DROP TABLE IF EXISTS `cw_purcate_model`;
CREATE TABLE `cw_purcate_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `pid` int(10) NOT NULL COMMENT '栏目ID',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=267 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `cw_purcate_model`
-- -----------------------------
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_purcate_model` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_purchase`
-- -----------------------------
DROP TABLE IF EXISTS `cw_purchase`;
CREATE TABLE `cw_purchase` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `price` varchar(255) NOT NULL COMMENT '团购价格',
  `number` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '团购人数',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '团购汽车封面',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `update_time` int(10) NOT NULL COMMENT '更新时间',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `model_id` tinyint(3) unsigned NOT NULL COMMENT '文档类型id',
  `pid` int(10) unsigned NOT NULL COMMENT '所属ID',
  `root` int(10) unsigned NOT NULL COMMENT '根节点',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `uid` int(10) unsigned NOT NULL COMMENT '用户ID',
  `level` int(10) unsigned NOT NULL COMMENT '优先级',
  `view` int(10) unsigned NOT NULL COMMENT '浏览量',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=573 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `cw_purchase`
-- -----------------------------
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_purchase` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_purchase_purlist`
-- -----------------------------
DROP TABLE IF EXISTS `cw_purchase_purlist`;
CREATE TABLE `cw_purchase_purlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `content` text NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=573 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `cw_purchase_purlist`
-- -----------------------------
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');
INSERT INTO `cw_purchase_purlist` VALUES ('', '');

-- -----------------------------
-- Table structure for `cw_sms`
-- -----------------------------
DROP TABLE IF EXISTS `cw_sms`;
CREATE TABLE `cw_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `key` char(32) NOT NULL,
  `resule` int(11) NOT NULL,
  `creat_time` int(10) NOT NULL,
  `last_time` int(10) NOT NULL,
  `status` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `cw_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `cw_ucenter_admin`;
CREATE TABLE `cw_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `cw_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `cw_ucenter_app`;
CREATE TABLE `cw_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `cw_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `cw_ucenter_member`;
CREATE TABLE `cw_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(64) DEFAULT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `openid` char(30) NOT NULL,
  `usertype` int(1) NOT NULL DEFAULT '0' COMMENT '0:个人,1:经销商,2:供应商',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `member_logo` int(10) DEFAULT NULL COMMENT '公司logo',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户状态',
  `headimgurl` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `cw_ucenter_member`
-- -----------------------------
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_ucenter_member` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `cw_ucenter_setting`;
CREATE TABLE `cw_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `cw_url`
-- -----------------------------
DROP TABLE IF EXISTS `cw_url`;
CREATE TABLE `cw_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `cw_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `cw_userdata`;
CREATE TABLE `cw_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `cw_userfiled`
-- -----------------------------
DROP TABLE IF EXISTS `cw_userfiled`;
CREATE TABLE `cw_userfiled` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `cw_userfiled`
-- -----------------------------
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_userfiled` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_usermodel`
-- -----------------------------
DROP TABLE IF EXISTS `cw_usermodel`;
CREATE TABLE `cw_usermodel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `cw_usermodel`
-- -----------------------------
INSERT INTO `cw_usermodel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_usermodel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_usermodel` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_verifycode`
-- -----------------------------
DROP TABLE IF EXISTS `cw_verifycode`;
CREATE TABLE `cw_verifycode` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `number` bigint(13) NOT NULL COMMENT '验证码',
  `uid` int(11) NOT NULL COMMENT '用户编号',
  `mobile` varchar(255) NOT NULL COMMENT '用户手机号码',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `status` int(11) NOT NULL COMMENT '数据状态（-1删除正数为未验证次数0为已验证）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `cw_view`
-- -----------------------------
DROP TABLE IF EXISTS `cw_view`;
CREATE TABLE `cw_view` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_view`
-- -----------------------------
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');
INSERT INTO `cw_view` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_wechat_config`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_config`;
CREATE TABLE `cw_wechat_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `wechatid` char(30) NOT NULL,
  `token` char(50) NOT NULL,
  `appID` char(20) NOT NULL,
  `appsecret` char(35) NOT NULL,
  `access_token` varchar(200) NOT NULL,
  `expires_in` int(11) NOT NULL,
  `menu` text NOT NULL,
  `admin_id` char(50) DEFAULT NULL,
  `type` int(3) NOT NULL DEFAULT '1' COMMENT '类型,1:订阅号;2:认证订阅号,3:服务号;4:认证服务号',
  `status` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_wechat_config`
-- -----------------------------
INSERT INTO `cw_wechat_config` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_wechat_dkh`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_dkh`;
CREATE TABLE `cw_wechat_dkh` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kf_account` char(30) CHARACTER SET utf8 NOT NULL,
  `nickname` char(20) CHARACTER SET utf8 NOT NULL,
  `password` char(32) CHARACTER SET utf8 NOT NULL,
  `wechatid` char(30) CHARACTER SET utf8 NOT NULL,
  `group` int(3) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `cw_wechat_dkh`
-- -----------------------------
INSERT INTO `cw_wechat_dkh` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_dkh` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_dkh` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_dkh` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_dkh` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_dkh` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_dkh` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_wechat_dkh_group`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_dkh_group`;
CREATE TABLE `cw_wechat_dkh_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` char(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `cw_wechat_dkh_group`
-- -----------------------------
INSERT INTO `cw_wechat_dkh_group` VALUES ('', '');
INSERT INTO `cw_wechat_dkh_group` VALUES ('', '');
INSERT INTO `cw_wechat_dkh_group` VALUES ('', '');

-- -----------------------------
-- Table structure for `cw_wechat_file`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_file`;
CREATE TABLE `cw_wechat_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `filetype` char(10) NOT NULL,
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `cw_wechat_file`
-- -----------------------------
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_file` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_wechat_file_media_id`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_file_media_id`;
CREATE TABLE `cw_wechat_file_media_id` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wechatid` char(30) NOT NULL,
  `fileid` int(11) NOT NULL,
  `type` char(10) NOT NULL,
  `media_id` char(64) NOT NULL DEFAULT '',
  `expires_in` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_wechat_file_media_id`
-- -----------------------------
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');
INSERT INTO `cw_wechat_file_media_id` VALUES ('', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_wechat_logs`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_logs`;
CREATE TABLE `cw_wechat_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `addtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4858 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_wechat_logs`
-- -----------------------------
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');
INSERT INTO `cw_wechat_logs` VALUES ('', '', '');

-- -----------------------------
-- Table structure for `cw_wechat_material`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_material`;
CREATE TABLE `cw_wechat_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` char(10) NOT NULL,
  `content` text NOT NULL,
  `fileid` int(11) NOT NULL,
  `addtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_wechat_material`
-- -----------------------------
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');
INSERT INTO `cw_wechat_material` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_wechat_menu`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_menu`;
CREATE TABLE `cw_wechat_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` char(30) NOT NULL,
  `wechatid` char(30) NOT NULL,
  `type` int(2) NOT NULL,
  `content` text NOT NULL,
  `orderby` int(11) NOT NULL,
  `status` smallint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_wechat_menu`
-- -----------------------------
INSERT INTO `cw_wechat_menu` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_menu` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_menu` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_menu` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_menu` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_menu` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_menu` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_menu` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_menu` VALUES ('', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_wechat_reply`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_reply`;
CREATE TABLE `cw_wechat_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL,
  `type` char(10) NOT NULL,
  `material` int(11) NOT NULL,
  `text` text NOT NULL,
  `keyword` text NOT NULL,
  `status` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_wechat_reply`
-- -----------------------------
INSERT INTO `cw_wechat_reply` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_reply` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_reply` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_reply` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_reply` VALUES ('', '', '', '', '', '', '');
INSERT INTO `cw_wechat_reply` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `cw_wechat_user`
-- -----------------------------
DROP TABLE IF EXISTS `cw_wechat_user`;
CREATE TABLE `cw_wechat_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wechatid` char(50) NOT NULL,
  `openid` char(30) NOT NULL,
  `nickname` char(30) NOT NULL,
  `sex` char(5) NOT NULL,
  `language` char(10) NOT NULL,
  `country` char(30) NOT NULL,
  `province` char(30) NOT NULL,
  `city` char(30) NOT NULL,
  `headimgurl` text NOT NULL,
  `addtime` int(11) NOT NULL,
  `logtime` int(11) NOT NULL,
  `subscribe` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=544 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `cw_wechat_user`
-- -----------------------------
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `cw_wechat_user` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '');
